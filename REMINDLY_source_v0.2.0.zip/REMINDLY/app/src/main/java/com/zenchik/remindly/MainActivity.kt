package com.zenchik.remindly

import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zenchik.remindly.data.Reminder
import com.zenchik.remindly.ui.ReminderViewModel

private val Ink = Color(0xFF050505)
private val Panel = Color(0xFF151515)
private val Silver = Color(0xFFD8D8D8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderNotifications.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7001)
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Ink, surface = Panel, primary = Silver,
                onBackground = Color.White, onSurface = Color.White
            )) {
                val vm: ReminderViewModel = viewModel()
                RemindlyHome(vm)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RemindlyHome(vm: ReminderViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val reminders by vm.reminders.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("") }
    var remindAt by remember { mutableStateOf(System.currentTimeMillis() + 60 * 60 * 1000L) }
    val dateLabel = remember(remindAt) {
        SimpleDateFormat("dd.MM.yyyy, HH:mm", Locale.getDefault()).format(Date(remindAt))
    }

    Scaffold(
        containerColor = Ink,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("REMINDLY", fontWeight = FontWeight.Black, letterSpacing = androidx.compose.ui.unit.TextUnit.Unspecified)
                        Text("CREATED BY ZENCHIK", style = MaterialTheme.typography.labelSmall, color = Silver)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink, titleContentColor = Color.White)
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }, containerColor = Silver, contentColor = Ink) {
                Icon(Icons.Default.Add, contentDescription = "Создать напоминание")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 100.dp)
        ) {
            item {
                Text("ТВОИ НАПОМИНАНИЯ", style = MaterialTheme.typography.labelMedium, color = Silver)
                Spacer(Modifier.height(5.dp))
                Text("Не упусти важное", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            }
            item {
                Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("БЛИЖАЙШЕЕ", color = Silver, style = MaterialTheme.typography.labelSmall)
                        Spacer(Modifier.height(8.dp))
                        Text(reminders.firstOrNull { !it.done }?.title ?: "Пока всё спокойно", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text(if (reminders.any { !it.done }) "Открой задачу, чтобы посмотреть подробности" else "Добавь первое напоминание", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item { Text("ВСЕ ЗАДАЧИ", color = Silver, style = MaterialTheme.typography.labelMedium) }
            if (reminders.isEmpty()) {
                item {
                    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                        Text("Здесь появятся твои напоминания", Modifier.padding(20.dp), color = Color.LightGray)
                    }
                }
            }
            items(reminders, key = { it.id }) { item ->
                ReminderCard(item, onDone = { vm.markDone(item) }, onDelete = { vm.delete(item) })
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Новое напоминание") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Что нужно сделать?") }, singleLine = true)
                    OutlinedTextField(value = details, onValueChange = { details = it }, label = { Text("Подробности (необязательно)") })
                    OutlinedButton(onClick = {
                        val c = Calendar.getInstance().apply { timeInMillis = remindAt }
                        DatePickerDialog(
                            context,
                            { _, year, month, day ->
                            val chosen = Calendar.getInstance().apply {
                                timeInMillis = remindAt
                                set(Calendar.YEAR, year)
                                set(Calendar.MONTH, month)
                                set(Calendar.DAY_OF_MONTH, day)
                            }
                            TimePickerDialog(
                                context,
                                { _, hour, minute ->
                                    chosen.set(Calendar.HOUR_OF_DAY, hour)
                                    chosen.set(Calendar.MINUTE, minute)
                                    chosen.set(Calendar.SECOND, 0)
                                    remindAt = chosen.timeInMillis
                                },
                                c.get(Calendar.HOUR_OF_DAY),
                                c.get(Calendar.MINUTE),
                                true
                            ).show()
                            },
                            c.get(Calendar.YEAR),
                            c.get(Calendar.MONTH),
                            c.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Schedule, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Напомнить: $dateLabel")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (title.isNotBlank()) vm.add(title.trim(), details.trim(), remindAt)
                    title = ""; details = ""; remindAt = System.currentTimeMillis() + 60 * 60 * 1000L; showAdd = false
                }) { Text("Создать") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Отмена") } },
            containerColor = Panel
        )
    }
}

@Composable
private fun ReminderCard(item: Reminder, onDone: () -> Unit, onDelete: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium,
                    color = if (item.done) Color.Gray else Color.White)
                if (item.details.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(item.details, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                }
                Text(if (item.done) "ВЫПОЛНЕНО" else "АКТИВНО", color = Silver, style = MaterialTheme.typography.labelSmall)
                item.remindAt?.let {
                    Text(SimpleDateFormat("dd.MM.yyyy • HH:mm", Locale.getDefault()).format(Date(it)),
                        color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                }
            }
            IconButton(onClick = onDone) { Icon(Icons.Default.CheckCircle, contentDescription = "Выполнено", tint = Silver) }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = Color.Gray) }
        }
    }
}
