package com.zenchik.remindly.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val details: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val done: Boolean = false,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val radiusMeters: Int = 200,
    val remindAt: Long? = null,
    val repeatMinutes: Int = 5
)
