package com.zenchik.remindly.notifications

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.zenchik.remindly.ReminderNotifications
import com.zenchik.remindly.data.RemindlyDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(EXTRA_ID, -1L)
        if (id <= 0L) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = RemindlyDatabase.get(context).reminderDao()
                val reminder = dao.getById(id) ?: return@launch
                if (reminder.done) return@launch

                when (intent.action) {
                    ACTION_DONE -> {
                        dao.update(reminder.copy(done = true))
                        ReminderScheduler.cancel(context, id)
                        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(id.toInt())
                    }
                    ACTION_SNOOZE -> {
                        val updated = reminder.copy(remindAt = System.currentTimeMillis() + 10 * 60 * 1000L)
                        dao.update(updated)
                        ReminderScheduler.schedule(context, updated)
                        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(id.toInt())
                    }
                    else -> {
                        val doneIntent = actionIntent(context, id, ACTION_DONE)
                        val snoozeIntent = actionIntent(context, id, ACTION_SNOOZE)
                        val notification = NotificationCompat.Builder(context, ReminderNotifications.CHANNEL_ID)
                            .setSmallIcon(android.R.drawable.ic_dialog_info)
                            .setContentTitle(reminder.title)
                            .setContentText(reminder.details.ifBlank { "Время вспомнить об этом" })
                            .setStyle(NotificationCompat.BigTextStyle().bigText(reminder.details.ifBlank { "Время вспомнить об этом" }))
                            .setPriority(NotificationCompat.PRIORITY_HIGH)
                            .setAutoCancel(true)
                            .addAction(android.R.drawable.checkbox_on_background, "Выполнено", doneIntent)
                            .addAction(android.R.drawable.ic_lock_idle_alarm, "Отложить на 10 мин", snoozeIntent)
                            .build()
                        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id.toInt(), notification)
                    }
                }
            } finally {
                pending.finish()
            }
        }
    }

    private fun actionIntent(context: Context, id: Long, action: String) =
        android.app.PendingIntent.getBroadcast(
            context, (id.toInt() * 31) + action.hashCode(),
            Intent(context, ReminderReceiver::class.java).apply {
                this.action = action
                putExtra(EXTRA_ID, id)
            },
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )

    companion object {
        const val EXTRA_ID = "reminder_id"
        const val ACTION_FIRE = "com.zenchik.remindly.FIRE"
        const val ACTION_DONE = "com.zenchik.remindly.DONE"
        const val ACTION_SNOOZE = "com.zenchik.remindly.SNOOZE"
    }
}
