package com.zenchik.remindly.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zenchik.remindly.data.Reminder
import com.zenchik.remindly.data.RemindlyDatabase
import com.zenchik.remindly.notifications.ReminderScheduler
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ReminderViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = RemindlyDatabase.get(app).reminderDao()
    val reminders = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun add(title: String, details: String, remindAt: Long?) = viewModelScope.launch {
        val reminder = Reminder(title = title, details = details, remindAt = remindAt)
        val id = dao.insert(reminder)
        ReminderScheduler.schedule(getApplication(), reminder.copy(id = id))
    }
    fun markDone(item: Reminder) = viewModelScope.launch {
        dao.update(item.copy(done = true))
        ReminderScheduler.cancel(getApplication(), item.id)
    }
    fun delete(item: Reminder) = viewModelScope.launch {
        dao.delete(item)
        ReminderScheduler.cancel(getApplication(), item.id)
    }
}
