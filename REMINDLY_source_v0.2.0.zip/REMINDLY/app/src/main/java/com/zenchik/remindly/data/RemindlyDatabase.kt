package com.zenchik.remindly.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Reminder::class], version = 1, exportSchema = false)
abstract class RemindlyDatabase : RoomDatabase() {
    abstract fun reminderDao(): ReminderDao
    companion object {
        @Volatile private var INSTANCE: RemindlyDatabase? = null
        fun get(context: Context): RemindlyDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, RemindlyDatabase::class.java, "remindly.db").build().also { INSTANCE = it }
        }
    }
}
