package com.zenchik.remindly.notifications

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.zenchik.remindly.ReminderNotifications
import com.zenchik.remindly.data.RemindlyDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                ReminderNotifications.createChannel(context)
                val tasks = RemindlyDatabase.get(context).reminderDao().getPending()
                tasks.forEach { ReminderScheduler.schedule(context, it) }
                if (tasks.isNotEmpty()) {
                    val text = tasks.take(4).joinToString(" • ") { it.title }
                    val notification = NotificationCompat.Builder(context, ReminderNotifications.CHANNEL_ID)
                        .setSmallIcon(android.R.drawable.ic_dialog_info)
                        .setContentTitle("Телефон был перезагружен")
                        .setContentText("Вот ваши невыполненные задачи: $text")
                        .setStyle(NotificationCompat.BigTextStyle().bigText("Вот ваши невыполненные задачи: $text"))
                        .setAutoCancel(true)
                        .build()
                    context.getSystemService(NotificationManager::class.java).notify(4601, notification)
                }
            } finally {
                pending.finish()
            }
        }
    }
}
