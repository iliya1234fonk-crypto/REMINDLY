package com.zenchik.remindly

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

object ReminderNotifications {
    const val CHANNEL_ID = "remindly_reminders_v2"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Напоминания REMINDLY",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Напоминания о важных делах"
                enableVibration(false)
            }
            manager.createNotificationChannel(channel)
        }
    }
}
