package com.zenchik.remindly.notifications

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.zenchik.remindly.R
import com.zenchik.remindly.ReminderNotifications
import com.zenchik.remindly.ReminderScheduler
import com.zenchik.remindly.data.RemindlyDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                ReminderNotifications.createChannel(context)
                val tasks = RemindlyDatabase.get(context).reminderDao().getPending()
                tasks.forEach { ReminderScheduler.schedule(context, it) }
                if (tasks.isNotEmpty()) {
                    val summary = tasks.take(4).joinToString(" • ") { it.title }
                    val open = android.app.PendingIntent.getActivity(
                        context, 4602,
                        Intent(context, com.zenchik.remindly.MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        },
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                    )
                    val notification = NotificationCompat.Builder(context, ReminderNotifications.CHANNEL_ID)
                        .setSmallIcon(R.drawable.ic_stat_remindly)
                        .setContentTitle("Телефон был перезагружен")
                        .setContentText("Вот ваши невыполненные задачи: $summary")
                        .setStyle(NotificationCompat.BigTextStyle().bigText("Вот ваши невыполненные задачи: $summary"))
                        .setContentIntent(open)
                        .setAutoCancel(true)
                        .build()
                    context.getSystemService(NotificationManager::class.java).notify(4601, notification)
                }
            } finally {
                pending.finish()
            }
        }
    }
}
