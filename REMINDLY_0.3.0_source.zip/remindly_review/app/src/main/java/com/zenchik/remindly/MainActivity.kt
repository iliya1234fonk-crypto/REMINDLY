package com.zenchik.remindly

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zenchik.remindly.data.Reminder
import com.zenchik.remindly.ui.ReminderViewModel
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import com.zenchik.remindly.data.RemindlyDatabase
import androidx.room.withTransaction

private val Ink = Color(0xFF070809)
private val Panel = Color(0xFF17191C)
private val Silver = Color(0xFFD8DDE2)
private val Muted = Color(0xFF9299A1)
private val Gold = Color(0xFFFFD45C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderNotifications.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        setContent {
            val prefs = getSharedPreferences("remindly_settings", MODE_PRIVATE)
            var theme by remember { mutableStateOf(prefs.getString("theme", "dark") ?: "dark") }
            val dark = theme == "dark" || (theme == "system" && androidx.compose.foundation.isSystemInDarkTheme())
            MaterialTheme(colorScheme = if (dark) darkColorScheme(
                background = Ink, surface = Panel, primary = Silver, secondary = Gold,
                onBackground = Color.White, onSurface = Color.White
            ) else lightColorScheme(
                background = Color(0xFFF3F4F6), surface = Color.White, primary = Color(0xFF20252B),
                secondary = Color(0xFF8A6A19), onBackground = Color(0xFF151719), onSurface = Color(0xFF151719)
            )) {
                val vm: ReminderViewModel = viewModel()
                var splash by remember { mutableStateOf(true) }
                LaunchedEffect(Unit) { delay(1350); splash = false }
                if (splash) BrandSplash() else RemindlyHome(vm, theme, onTheme = {
                    theme = it
                    prefs.edit().putString("theme", it).apply()
                })
            }
        }
    }
}

@Composable
private fun BrandSplash() {
    val transition = rememberInfiniteTransition(label = "metal-splash")
    val offset by transition.animateFloat(
        initialValue = -180f,
        targetValue = 180f,
        animationSpec = infiniteRepeatable(tween(1700), RepeatMode.Reverse),
        label = "metal-sheen"
    )
    Box(Modifier.fillMaxSize().background(Color(0xFF070809)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "R",
                style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Black),
                color = Silver,
                modifier = Modifier.background(Brush.linearGradient(listOf(Color(0xFF5F6872), Color.White, Color(0xFF7D8791)), start = androidx.compose.ui.geometry.Offset(offset, 0f), end = androidx.compose.ui.geometry.Offset(offset + 220f, 220f)))
            )
            Spacer(Modifier.height(12.dp))
            Text("REMINDLY", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
            Text("CREATED BY ZENCHIK", color = Silver, style = MaterialTheme.typography.labelSmall, letterSpacing = 2.sp)
        }
    }
}

private enum class Section(val label: String) { ACTIVE("Активные"), DONE("Выполнено"), FAVORITES("Избранное"), ARCHIVE("Архив"), TRASH("Корзина"), SETTINGS("Настройки") }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RemindlyHome(vm: ReminderViewModel, theme: String, onTheme: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val reminders by vm.reminders.collectAsState()
    var section by remember { mutableStateOf(Section.ACTIVE) }
    var showAdd by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("") }
    var tag by remember { mutableStateOf("") }
    var priority by remember { mutableIntStateOf(1) }
    var remindAt by remember { mutableStateOf<Long?>(null) }
    var extra by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf("") }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            runCatching {
                val root = JSONObject().put("app", "REMINDLY").put("version", 1).put("theme", theme)
                val array = JSONArray()
                reminders.forEach { r -> array.put(JSONObject()
                    .put("id", r.id).put("title", r.title).put("details", r.details)
                    .put("createdAt", r.createdAt).put("done", r.done).put("latitude", r.latitude ?: JSONObject.NULL)
                    .put("longitude", r.longitude ?: JSONObject.NULL).put("radiusMeters", r.radiusMeters)
                    .put("remindAt", r.remindAt ?: JSONObject.NULL).put("repeatMinutes", r.repeatMinutes)
                    .put("priority", r.priority).put("tag", r.tag).put("favorite", r.favorite)
                    .put("archived", r.archived).put("deleted", r.deleted)) }
                root.put("reminders", array)
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(root.toString(2)) }
                info = "Резервная копия сохранена"
            }.onFailure { info = "Не удалось создать копию: ${it.localizedMessage}" }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                            ?: error("Не удалось прочитать файл")
                        val root = JSONObject(raw)
                        require(root.optString("app") == "REMINDLY") { "Это не резервная копия REMINDLY" }
                        val array = root.getJSONArray("reminders")
                        val restored = buildList {
                            for (i in 0 until array.length()) {
                                val o = array.getJSONObject(i)
                                add(Reminder(
                                    id = o.optLong("id"), title = o.getString("title"), details = o.optString("details"),
                                    createdAt = o.optLong("createdAt", System.currentTimeMillis()), done = o.optBoolean("done"),
                                    latitude = if (o.isNull("latitude")) null else o.optDouble("latitude"),
                                    longitude = if (o.isNull("longitude")) null else o.optDouble("longitude"),
                                    radiusMeters = o.optInt("radiusMeters", 200),
                                    remindAt = if (o.isNull("remindAt")) null else o.optLong("remindAt"),
                                    repeatMinutes = o.optInt("repeatMinutes", 5), priority = o.optInt("priority", 1),
                                    tag = o.optString("tag"), favorite = o.optBoolean("favorite"),
                                    archived = o.optBoolean("archived"), deleted = o.optBoolean("deleted")
                                ))
                            }
                        }
                        val database = RemindlyDatabase.get(context)
                        database.withTransaction {
                            database.reminderDao().deleteAll()
                            database.reminderDao().insertAll(restored)
                        }
                        restored.forEach { ReminderScheduler.schedule(context, it) }
                        root.optString("theme", "").takeIf { it in listOf("dark", "light", "system") }
                    }
                }
                result.onSuccess { importedTheme ->
                    if (importedTheme != null) onTheme(importedTheme)
                    info = "Резервная копия восстановлена"
                }.onFailure { info = "Не удалось восстановить копию: ${it.localizedMessage}" }
            }
        }
    }

    val visible = reminders.filter { r ->
        val matchesSearch = search.isBlank() || r.title.contains(search, true) || r.details.contains(search, true) || r.tag.contains(search, true)
        matchesSearch && when (section) {
            Section.ACTIVE -> !r.done && !r.archived && !r.deleted
            Section.DONE -> r.done && !r.deleted
            Section.FAVORITES -> r.favorite && !r.done && !r.deleted
            Section.ARCHIVE -> r.archived && !r.deleted
            Section.TRASH -> r.deleted
            Section.SETTINGS -> false
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Column {
                    Text("REMINDLY", fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("CREATED BY ZENCHIK", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            if (section == Section.ACTIVE) FloatingActionButton(onClick = { showAdd = true }, containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.background) {
                Icon(Icons.Default.Add, contentDescription = "Создать напоминание")
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Section.values().forEach { item ->
                    FilterChip(selected = section == item, onClick = { section = item }, label = { Text(item.label, maxLines = 1) })
                }
            }
            if (section == Section.SETTINGS) {
                SettingsScreen(theme, onTheme, onExport = { exportLauncher.launch("REMINDLY_backup.json") }, onImport = { importLauncher.launch(arrayOf("application/json", "text/json")) }, onExactAlarm = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")))
                    }
                })
            } else {
                OutlinedTextField(
                    value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    placeholder = { Text("Поиск напоминаний") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true
                )
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (section == Section.ACTIVE) item {
                        NearestCard(reminders.firstOrNull { !it.done && !it.archived && !it.deleted })
                    }
                    if (visible.isEmpty()) item {
                        Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                            Text(if (search.isNotBlank()) "Ничего не найдено" else "Здесь пока пусто", Modifier.padding(22.dp), color = Muted)
                        }
                    }
                    items(visible, key = { it.id }) { item ->
                        ReminderCard(
                            item = item,
                            onDone = { vm.markDone(item) },
                            onDelete = { vm.delete(item) },
                            onFavorite = { vm.toggleFavorite(item) },
                            onArchive = { vm.archive(item) },
                            onRestore = { vm.restore(item) },
                            onDeleteForever = { vm.deleteForever(item) }
                        )
                    }
                }
            }
        }
    }

    if (info.isNotBlank()) AlertDialog(onDismissRequest = { info = "" }, confirmButton = { TextButton(onClick = { info = "" }) { Text("ОК") } }, text = { Text(info) })

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Новое напоминание") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Что нужно сделать?") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = {
                            val c = Calendar.getInstance().apply { timeInMillis = remindAt ?: (System.currentTimeMillis() + 3_600_000L) }
                            DatePickerDialog(context, { _, y, m, d ->
                                val updated = Calendar.getInstance().apply { timeInMillis = remindAt ?: (System.currentTimeMillis() + 3_600_000L); set(y, m, d) }
                                remindAt = updated.timeInMillis
                            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                        }) { Text(remindAt?.let { SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(it)) } ?: "Дата") }
                        OutlinedButton(onClick = {
                            val c = Calendar.getInstance().apply { timeInMillis = remindAt ?: (System.currentTimeMillis() + 3_600_000L) }
                            TimePickerDialog(context, { _, h, m ->
                                val updated = Calendar.getInstance().apply { timeInMillis = remindAt ?: (System.currentTimeMillis() + 3_600_000L); set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0) }
                                remindAt = updated.timeInMillis
                            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
                        }) { Text(remindAt?.let { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(it)) } ?: "Время") }
                    }
                    TextButton(onClick = { extra = !extra }) { Text(if (extra) "Скрыть дополнительные настройки" else "Дополнительные настройки") }
                    AnimatedVisibility(extra) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = details, onValueChange = { details = it }, label = { Text("Подробности") })
                            OutlinedTextField(value = tag, onValueChange = { tag = it }, label = { Text("Тег") }, singleLine = true)
                            Text("Приоритет")
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("Низкий", "Обычный", "Высокий").forEachIndexed { index, label ->
                                    FilterChip(selected = priority == index, onClick = { priority = index }, label = { Text(label) })
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = {
                if (title.isNotBlank()) vm.add(title.trim(), details.trim(), remindAt, priority, tag.trim())
                title = ""; details = ""; tag = ""; remindAt = null; priority = 1; extra = false; showAdd = false
            }) { Text("Создать") } },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Отмена") } },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }
}

@Composable
private fun NearestCard(item: Reminder?) {
    val left = item?.remindAt?.minus(System.currentTimeMillis())
    val ratio = if (left == null) 1f else (left.toFloat() / 86_400_000f).coerceIn(0f, 1f)
    val animated by animateFloatAsState(ratio, animationSpec = tween(700, easing = FastOutSlowInEasing), label = "time-ring")
    val ringColor = when { left == null -> Silver; left < 0 -> Color(0xFFFF5555); left < 30 * 60_000L -> Color(0xFFFF7B36); left < 2 * 60 * 60_000L -> Gold; else -> Silver }
    Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(58.dp).clip(CircleShape).background(ringColor.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(progress = animated, modifier = Modifier.fillMaxSize(), color = ringColor, trackColor = ringColor.copy(alpha = 0.12f), strokeWidth = 4.dp)
                Text("◷", color = ringColor, style = MaterialTheme.typography.titleLarge)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("БЛИЖАЙШЕЕ НАПОМИНАНИЕ", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                Text(item?.title ?: "Пока всё спокойно", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(item?.remindAt?.let { SimpleDateFormat("dd MMMM · HH:mm", Locale("ru")).format(Date(it)) } ?: "Добавь первое напоминание", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ReminderCard(item: Reminder, onDone: () -> Unit, onDelete: () -> Unit, onFavorite: () -> Unit, onArchive: () -> Unit, onRestore: () -> Unit, onDeleteForever: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium, color = if (item.done) Muted else MaterialTheme.colorScheme.onSurface)
                    if (item.remindAt != null) Text(SimpleDateFormat("dd.MM.yyyy · HH:mm", Locale.getDefault()).format(Date(item.remindAt)), color = Muted, style = MaterialTheme.typography.bodySmall)
                }
                if (item.priority == 2) Text("ВАЖНО", color = Color(0xFFFF7B36), style = MaterialTheme.typography.labelSmall)
                IconButton(onClick = onFavorite) { Icon(if (item.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (item.favorite) Color(0xFFE46B80) else Muted) }
            }
            if (item.details.isNotBlank()) Text(item.details, color = Muted, style = MaterialTheme.typography.bodyMedium, maxLines = 3, overflow = TextOverflow.Ellipsis)
            if (item.tag.isNotBlank()) Text("#${item.tag}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                when {
                    item.deleted -> {
                        TextButton(onClick = onRestore) { Text("Восстановить") }
                        TextButton(onClick = onDeleteForever) { Text("Удалить навсегда") }
                    }
                    item.archived -> TextButton(onClick = onRestore) { Text("Вернуть") }
                    item.done -> Text("ВЫПОЛНЕНО", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(10.dp))
                    else -> {
                        TextButton(onClick = onDone) { Icon(Icons.Default.CheckCircle, null); Spacer(Modifier.width(4.dp)); Text("Готово") }
                        TextButton(onClick = onArchive) { Icon(Icons.Default.Archive, null); Spacer(Modifier.width(4.dp)); Text("Архив") }
                        TextButton(onClick = onDelete) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(4.dp)); Text("Удалить") }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(theme: String, onTheme: (String) -> Unit, onExport: () -> Unit, onImport: () -> Unit, onExactAlarm: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("ВНЕШНИЙ ВИД", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
        Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Тема приложения", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("dark" to "Тёмная", "light" to "Светлая", "system" to "Авто").forEach { (value, label) ->
                        FilterChip(selected = theme == value, onClick = { onTheme(value) }, label = { Text(label) })
                    }
                }
            }
        }
        Text("ДАННЫЕ", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
        Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Резервная копия", style = MaterialTheme.typography.titleMedium)
                Text("Сохрани напоминания в один JSON-файл, чтобы перенести их на другое устройство", color = Muted, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onExport) { Text("Экспорт") }
                    OutlinedButton(onClick = onImport) { Text("Импорт") }
                }
            }
        }
        Text("УВЕДОМЛЕНИЯ", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
        Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Точные напоминания", style = MaterialTheme.typography.titleMedium)
                Text("Для максимально точного времени Android может попросить отдельное разрешение", color = Muted, style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = onExactAlarm) { Text("Разрешить точные уведомления") }
            }
        }
        Text("REMINDLY by Zenchik · 1.0.0", color = Muted, style = MaterialTheme.typography.labelSmall)
    }
}
