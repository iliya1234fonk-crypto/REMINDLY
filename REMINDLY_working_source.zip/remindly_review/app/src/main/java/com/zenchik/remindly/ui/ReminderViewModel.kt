package com.zenchik.remindly.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zenchik.remindly.ReminderScheduler
import com.zenchik.remindly.data.Reminder
import com.zenchik.remindly.data.RemindlyDatabase
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ReminderViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = RemindlyDatabase.get(app).reminderDao()
    val reminders = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun add(title: String, details: String, remindAt: Long?, priority: Int, tag: String,
            repeatRule: String = "NONE", repeatInterval: Int = 1, latitude: Double? = null, longitude: Double? = null, radiusMeters: Int = 200) = viewModelScope.launch {
        val draft = Reminder(title = title, details = details, remindAt = remindAt, priority = priority,
            tag = tag, repeatRule = repeatRule, repeatInterval = repeatInterval, latitude = latitude, longitude = longitude, radiusMeters = radiusMeters)
        val id = dao.insert(draft)
        if (remindAt != null) ReminderScheduler.schedule(getApplication(), draft.copy(id = id))
    }

    fun markDone(item: Reminder) = viewModelScope.launch {
        dao.update(item.copy(done = true))
        ReminderScheduler.cancel(getApplication(), item.id)
    }

    fun delete(item: Reminder) = viewModelScope.launch {
        dao.update(item.copy(deleted = true))
        ReminderScheduler.cancel(getApplication(), item.id)
    }

    fun restore(item: Reminder) = viewModelScope.launch { dao.update(item.copy(deleted = false, archived = false)) }
    fun toggleFavorite(item: Reminder) = viewModelScope.launch { dao.update(item.copy(favorite = !item.favorite)) }
    fun archive(item: Reminder) = viewModelScope.launch {
        dao.update(item.copy(archived = true))
        ReminderScheduler.cancel(getApplication(), item.id)
    }
    fun deleteForever(item: Reminder) = viewModelScope.launch {
        dao.delete(item)
        ReminderScheduler.cancel(getApplication(), item.id)
    }
    fun update(item: Reminder) = viewModelScope.launch {
        dao.update(item)
        ReminderScheduler.cancel(getApplication(), item.id)
        ReminderScheduler.schedule(getApplication(), item)
    }
}
