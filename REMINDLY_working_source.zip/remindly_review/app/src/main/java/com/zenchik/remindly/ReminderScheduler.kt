package com.zenchik.remindly

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.zenchik.remindly.data.Reminder
import com.zenchik.remindly.notifications.ReminderReceiver
import java.util.Calendar

object ReminderScheduler {
    fun schedule(context: Context, reminder: Reminder) {
        val time = reminder.snoozeUntil ?: reminder.remindAt ?: return
        if (reminder.done || reminder.deleted || reminder.archived || time <= System.currentTimeMillis()) return
        val manager = context.getSystemService(AlarmManager::class.java)
        val pending = pendingIntent(context, reminder.id)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pending)
            } else {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pending)
            }
        } catch (_: SecurityException) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pending)
        }
    }

    fun cancel(context: Context, id: Long) {
        context.getSystemService(AlarmManager::class.java).cancel(pendingIntent(context, id))
    }

    /** Computes the next calendar occurrence without drifting from the original local clock time. */
    fun nextOccurrence(reminder: Reminder, firedAt: Long): Long? {
        val base = reminder.remindAt ?: return null
        if (reminder.repeatRule == "NONE") return null
        val interval = reminder.repeatInterval.coerceAtLeast(1)
        val calendar = Calendar.getInstance().apply { timeInMillis = base }
        when (reminder.repeatRule) {
            "INTERVAL" -> {
                val minutes = reminder.repeatMinutes.coerceAtLeast(1)
                var next = base
                while (next <= firedAt) next += minutes * 60_000L
                return next
            }
            "DAILY" -> {
                do { calendar.add(Calendar.DAY_OF_YEAR, interval) } while (calendar.timeInMillis <= firedAt)
            }
            "WEEKLY" -> {
                val selected = reminder.repeatDaysOfWeek.split(',').mapNotNull { it.toIntOrNull() }.filter { it in 1..7 }.toSet()
                if (selected.isEmpty()) {
                    do { calendar.add(Calendar.DAY_OF_YEAR, 7 * interval) } while (calendar.timeInMillis <= firedAt)
                } else {
                    val candidate = Calendar.getInstance().apply { timeInMillis = maxOf(base, firedAt) }
                    candidate.set(Calendar.SECOND, calendar.get(Calendar.SECOND))
                    candidate.set(Calendar.MILLISECOND, calendar.get(Calendar.MILLISECOND))
                    candidate.set(Calendar.HOUR_OF_DAY, calendar.get(Calendar.HOUR_OF_DAY))
                    candidate.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE))
                    candidate.add(Calendar.MINUTE, 1)
                    while (candidate.get(Calendar.DAY_OF_WEEK).toIsoDay() !in selected || candidate.timeInMillis <= firedAt) {
                        candidate.add(Calendar.DAY_OF_YEAR, 1)
                    }
                    return candidate.timeInMillis
                }
            }
            "MONTHLY" -> {
                do { calendar.add(Calendar.MONTH, interval) } while (calendar.timeInMillis <= firedAt)
            }
            else -> return null
        }
        return calendar.timeInMillis
    }

    private fun Int.toIsoDay(): Int = if (this == Calendar.SUNDAY) 7 else this - 1

    private fun pendingIntent(context: Context, id: Long): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = ReminderReceiver.ACTION_SHOW
            putExtra(ReminderReceiver.EXTRA_ID, id)
        }
        return PendingIntent.getBroadcast(
            context, id.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
