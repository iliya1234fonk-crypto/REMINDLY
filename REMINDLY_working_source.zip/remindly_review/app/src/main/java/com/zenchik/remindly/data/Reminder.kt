package com.zenchik.remindly.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val details: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val done: Boolean = false,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val radiusMeters: Int = 200,
    val remindAt: Long? = null,
    val repeatMinutes: Int = 5,
    val priority: Int = 1,
    val tag: String = "",
    val favorite: Boolean = false,
    val archived: Boolean = false,
    val deleted: Boolean = false,
    // NONE, DAILY, WEEKLY, MONTHLY, INTERVAL
    val repeatRule: String = "NONE",
    val repeatInterval: Int = 1,
    // ISO weekday numbers (1=Monday..7=Sunday), comma-separated
    val repeatDaysOfWeek: String = "",
    // A snooze is independent from the next recurring occurrence.
    val snoozeUntil: Long? = null,
    val soundUri: String? = null,
    val vibrate: Boolean = true,
    // JSON payloads keep checklist and attachment metadata local and migration-safe.
    val checklistJson: String = "[]",
    val attachmentsJson: String = "[]"
)
