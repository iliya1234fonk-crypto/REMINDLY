package com.zenchik.remindly.notifications

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.zenchik.remindly.MainActivity
import com.zenchik.remindly.ReminderNotifications
import com.zenchik.remindly.ReminderScheduler
import com.zenchik.remindly.data.RemindlyDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(EXTRA_ID, -1L)
        if (id <= 0L) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = RemindlyDatabase.get(context).reminderDao()
                val item = dao.getById(id) ?: return@launch
                if (item.done || item.deleted || item.archived) {
                    context.getSystemService(NotificationManager::class.java).cancel(id.toInt())
                    ReminderScheduler.cancel(context, id)
                    return@launch
                }
                val manager = context.getSystemService(NotificationManager::class.java)
                when (intent.action) {
                    ACTION_DONE -> {
                        dao.update(item.copy(done = true))
                        manager.cancel(id.toInt())
                        ReminderScheduler.cancel(context, id)
                    }
                    ACTION_SNOOZE, ACTION_GOING -> {
                        val delay = if (intent.action == ACTION_GOING) 15 else 10
                        val updated = item.copy(snoozeUntil = System.currentTimeMillis() + delay * 60_000L)
                        dao.update(updated)
                        manager.cancel(id.toInt())
                        ReminderScheduler.schedule(context, updated)
                    }
                    ACTION_EXPLAIN -> {
                        val open = Intent(context, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                            putExtra(EXTRA_ID, id)
                        }
                        context.startActivity(open)
                    }
                    else -> {
                        val now = System.currentTimeMillis()
                        val updated = if (item.snoozeUntil != null) {
                            item.copy(snoozeUntil = null)
                        } else {
                            val next = ReminderScheduler.nextOccurrence(item, now)
                            if (next != null) item.copy(remindAt = next) else item
                        }
                        if (updated != item) dao.update(updated)
                        if (updated.remindAt != item.remindAt || updated.snoozeUntil == null && item.snoozeUntil != null) {
                            ReminderScheduler.schedule(context, updated)
                        }
                        showReminder(context, item.id, item.title, item.details)
                    }
                }
            } finally {
                pending.finish()
            }
        }
    }

    private fun showReminder(context: Context, id: Long, title: String, details: String) {
        ReminderNotifications.createChannel(context)
        val manager = context.getSystemService(NotificationManager::class.java)
        fun action(action: String, request: Int, label: String): PendingIntent {
            val i = Intent(context, ReminderReceiver::class.java).apply {
                this.action = action
                putExtra(EXTRA_ID, id)
            }
            return PendingIntent.getBroadcast(context, request, i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        val openIntent = PendingIntent.getActivity(
            context, (id + 900_000).toInt(), Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val explainIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_ID, id)
        }
        val explainPending = PendingIntent.getActivity(
            context, (id + 4).toInt(), explainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val text = details.ifBlank { "Пора заняться этим делом" }
        val notification = NotificationCompat.Builder(context, ReminderNotifications.CHANNEL_ID)
            .setSmallIcon(com.zenchik.remindly.R.drawable.ic_stat_remindly)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(0, "Выполнено", action(ACTION_DONE, (id + 1).toInt(), "Выполнено"))
            .addAction(0, "Иду", action(ACTION_GOING, (id + 2).toInt(), "Иду"))
            .addAction(0, "Отложить", action(ACTION_SNOOZE, (id + 3).toInt(), "Отложить"))
            .addAction(0, "Объяснить", explainPending)
            .build()
        manager.notify(id.toInt(), notification)
    }

    companion object {
        const val EXTRA_ID = "reminder_id"
        const val ACTION_SHOW = "com.zenchik.remindly.SHOW"
        const val ACTION_DONE = "com.zenchik.remindly.DONE"
        const val ACTION_GOING = "com.zenchik.remindly.GOING"
        const val ACTION_SNOOZE = "com.zenchik.remindly.SNOOZE"
        const val ACTION_EXPLAIN = "com.zenchik.remindly.EXPLAIN"
    }
}
